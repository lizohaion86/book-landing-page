# איפה סבתא — דף נחיתה

קבצים להעלאה ל-GitHub Pages:
- `index.html`
- תיקיית `assets`

יש להעלות את כל התיקייה/הקבצים ל-repository ואז להפעיל GitHub Pages דרך Settings → Pages.
